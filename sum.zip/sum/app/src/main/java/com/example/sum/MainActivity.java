package com.example.sum;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int readNumber(int id){
        try {
            return Integer.parseInt(((EditText) findViewById(id)).getText().toString());
        }catch (NumberFormatException e){
            return 0;
        }
    }

    public void computeSum(View view){
        int number1=readNumber(R.id.firstNumber);
        int numero2=readNumber(R.id.secondNumber);
        if(view.getId()== R.id.subs) {
// handle button A click;
            ((TextView) findViewById(R.id.result)).setText("Substraction has been choseen and your result it is=" + Integer.toString(number1 - numero2));
        }
        if(view.getId()== R.id.sumButton){
// handle button B click;
                ((TextView)findViewById(R.id.result)).setText("Addition has been choseen and your result it is="+Integer.toString(number1+numero2));}
        if(view.getId()== R.id.mul) {
// handle button A click;
            ((TextView) findViewById(R.id.result)).setText("Multiplication has been choseen and your result it is=" + Integer.toString(number1 * numero2));
        }
        if(view.getId()== R.id.div) {
            if (numero2 == 0) {
                ((TextView) findViewById(R.id.result)).setText("Divition has been choseen and your result it is incalculable");
            } else {
                ((TextView) findViewById(R.id.result)).setText("Divition has been choseen and your result it is=" + Integer.toString(number1 / numero2));
// handle button B click;
            }
        }

    }
}
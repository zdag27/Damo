package com.example.sudoku;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Context;
        import android.content.res.ColorStateList;
        import android.graphics.Color;
        import android.graphics.Point;
        import android.os.Bundle;
        import android.view.Gravity;
        import android.view.View;
        import android.widget.Button;
        import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    int width;
    int height;
    int btsize;
    Cell[][] table;
    Cell[] lista;
    int fi;
    private class Cell{
        int val;
        Button bt;
        boolean fixed;
        int x;
        int y;
        Cell(Context THIS,int ini,int cx,int cy){
            x=cx;
            y=cy;
            val=ini;
            bt=new Button(THIS);
            bt.setText(val==0?"":Integer.toString(val));
            bt.setLayoutParams(new LinearLayout.LayoutParams(btsize,btsize));
            bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#808080")));
            bt.setTextSize(btsize/8);
            fixed=val!=0;
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(fixed) return;
                    val=(val+1)%10;
                    bt.setText(val==0?"":Integer.toString(val));
                    for (int q = 0; q < fi; q++) {
                        lista[q].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#808080")));
                    }
                    if(val!=0){
                        if(Revision(x,y)){
                            bt.setTextColor(Color.RED);
                        }else{
                            bt.setTextColor(Color.BLUE);
                        }
                    }
                    //checkTable();
                }
            });
        }
    }
    boolean Revision(int i,int j){
        Boolean res=false;
        Cell origen=table[i][j];
        int n=0;
        fi=0;
        while(n<9){
            if(n!=j){
                if(table[i][n].val== origen.val){
                    lista[fi]=table[i][n];
                    res=true;
                    table[i][n].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    fi+=1;
                }
            }
            if(n!=i){
                if(table[n][j].val== origen.val){
                    lista[fi]=table[n][j];
                    res=true;
                    table[n][j].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    System.out.println();
                    fi+=1;
                }
            }
            n+=1;
        }
        for (int t = i/3*3; t < i/3*3+3; t++) {
            for (int m = j/3*3; m < j/3*3+3; m++) {
                if((t!=i||j!=m) && table[i][j].val==table[t][m].val){
                    table[t][m].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    lista[fi]=table[t][m];
                    fi+=1;
                    res=true;
                }
            }
        }
        return res;
    }
    void checkTable(){
        for(int i=0;i<9;++i){
            for(int j=0;j<9;++j){
                Cell c=table[i][j];
                if(!c.fixed) {
                    if(issue(i,j)){
                        c.bt.setTextColor(Color.RED);
                    }else{
                        c.bt.setTextColor(Color.BLUE);
                    }
                }
            }
        }

    }
    Boolean issue(int i,int j){
        if(table[i][j].val==0) {System.out.println("val");return false;}
        if(issue(i,j,i,0,i+1,9)) {System.out.println("i1");return true;}
        if(issue(i,j,0,j,9,j+1)) {System.out.println("i2");return true;}
        if(issue(i,j,i/3*3,j/3*3,i/3*3+3,j/3*3+3)){ System.out.println("i3");return true;}
        System.out.println("fi");
        return false;
    }
    Boolean issue(int i,int j,int i1,int j1,int i2,int j2){
        for (int n = i1; n < i2; n++) {
            for (int m = j1; m < j2; m++) {
                if((n!=i||j!=m) && table[i][j].val==table[n][m].val){
                    return true;
                }
            }
        }
        return false;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        String[] textsudoku={
                "002000500",
                "010705020",
                "400090007",
                "049000730",
                "801030409",
                "036000210",
                "200080004",
                "080902060",
                "007000800"
        };
        int[] sudokure={0,
                3,
                0,
                9,
                4,
                7,
                6,
                5,
                8,
                7,
                6,
                4,
                3,
                5,
                8,
                9,
                1,
                0,
                9,
                5,
                8,
                1,
                2,
                6,
                4,
                7,
                3,
                5,
                1,
                2,
                7,
                8,
                4,
                0,
                9,
                6,
                3,
                7,
                6,
                2,
                9,
                5,
                8,
                4,
                0,
                4,
                8,
                9,
                6,
                1,
                3,
                0,
                2,
                7,
                8,
                9,
                7,
                4,
                3,
                2,
                1,
                6,
                5,
                1,
                2,
                0,
                5,
                6,
                9,
                7,
                8,
                4,
                6,
                4,
                5,
                8,
                7,
                1,
                0,
                3,
                9
        };

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        fi=0;
        Point point=new Point();
        getWindowManager().getDefaultDisplay().getSize(point);
        width=point.x;height=point.y;btsize=width/10;
        LinearLayout lin= new LinearLayout(this);
        lin.setOrientation(LinearLayout.VERTICAL);
        lin.setGravity(Gravity.CENTER);
        table=new Cell[9][9];
        lista=new Cell[9*3];
        for(int i=0;i<9;++i){
            LinearLayout lin2= new LinearLayout(this);
            lin2.setOrientation(LinearLayout.HORIZONTAL);
            lin2.setGravity(Gravity.CENTER_HORIZONTAL);
            for(int j=0;j<9;++j){
                table[i][j]=new Cell(this,/*textsudoku[i].charAt(j)-'0'*/sudokure[j+i*9],i,j);
                lin2.addView(table[i][j].bt);
            }
            lin.addView(lin2);
        }
        Button reset=new Button(this);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        if(!table[i][j].fixed){
                            table[i][j].bt.setText(0==0?"":Integer.toString(0));
                            table[i][j].bt.setTextColor(Color.BLACK);
                        }
                        table[i][j].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#808080")));
                    }
                }

            }
        });
        reset.setText("Reset");
        reset.setLayoutParams(new LinearLayout.LayoutParams(btsize*5,btsize));
        reset.setTextSize(btsize/6);
        lin.addView(reset);
        setContentView(lin);

    }
}


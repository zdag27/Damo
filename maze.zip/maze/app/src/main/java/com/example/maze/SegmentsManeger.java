package com.example.maze;

import java.util.ArrayList;

public class SegmentsManeger {
    ArrayList<Segment> list;
    int n;
    private class Cell{
        int i,j;
        boolean right,top;
        Cell identifier;
        Cell(){}
        Cell(int ini,int inj){
            i=ini;
            j=inj;
            identifier=this;
            right=true;
            top=true;
        }
    }
    private void recomputeIdentifier(Cell cell){
        if(cell.identifier==cell) return;
        recomputeIdentifier(cell.identifier);
        cell.identifier=cell.identifier.identifier;
    }
    private class Wall{
        Cell cell;
        int side;
        public Wall(Cell celli,int sidi){
            cell=celli;
            side=sidi;
        }
    }
    Cell[][] table;
    private void generateCells(){
        table=new Cell[n][n];
        for (int m = 0; m <n ; m++) {
            for (int k = 0; k <n ; k++) {
                table[m][k]=new Cell(m,k);

            }
        }
        ArrayList<Wall> listwalls=new ArrayList<>();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if(i<n-1)listwalls.add(new Wall(table[i][j],0));
                if(j<n-1)listwalls.add(new Wall(table[i][j],1));
            }
        }
        for (int i = 1; i < listwalls.size(); i++) {
            int inotherwall=(int)(Math.random()*(i+1));
            Wall wall=listwalls.get(i);
            Wall other=listwalls.get(inotherwall);
            listwalls.set(i,other);
            listwalls.set(inotherwall,wall);
        }
        for (int i = 0; i < listwalls.size(); i++) {
            Wall wall=listwalls.get(i);
            Cell cell= wall.cell;
            int side= wall.side;
            int ci=cell.i;
            int cj=cell.j;
            Cell ncell;
            if(side==0) ncell=table[ci+1][cj];
            else ncell=table[ci][cj+1];
            recomputeIdentifier(cell);
            recomputeIdentifier(ncell);
            Cell idcell=cell.identifier;
            Cell idncell=ncell.identifier;
            if(idncell==idcell) continue;
            idcell.identifier=idncell;
            if(side ==0) cell.right=false;
            else cell.top=false;
        }
    }
    private void generatesegments(){
        list = new ArrayList<>();
        list.add(new Segment(0,0,n,0));
        list.add(new Segment(0,0,0,n));
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                Cell cell=table[i][j];
                if(cell.right){
                    list.add(new Segment(i+1,j,i+1,j+1));
                }
                if(cell.top){
                    list.add(new Segment(i,j+1,i+1,j+1));
                }
            }
        }
    }
    public SegmentsManeger(){
        list = new ArrayList<>();
        list.add(new Segment(new point(0.5, 0), new point(0.5, 0.5)));
        list.add(new Segment(new point(-0.5, 0), new point(0, 0.5)));
    }
    public SegmentsManeger(int in){
        n=in;
        generateCells();
        generatesegments();
    }
}

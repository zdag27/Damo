package com.example.sumprogramed;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.IOException;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    final int TEXTSIZE=20;
    private int readNumber(EditText editText){
        try{
            return Integer.parseInt(editText.getText().toString());
        } catch (Exception e){
            return 0;
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        LinearLayout linlay=new LinearLayout(this);

        //String imageUrl="https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.educaciontrespuntocero.com%2Frecursos%2Fproblemas-de-matematicas-primaria%2F&psig=AOvVaw07sqgtj68WKaDMJFLL2nJW&ust=1631968081752000&source=images&cd=vfe&ved=0CAsQjRxqFwoTCPiXgYKBhvMCFQAAAAAdAAAAABAI";

        linlay.setOrientation(LinearLayout.VERTICAL);
        TextView info=new TextView(this);
        info.setText("write two numbers");
        info.setTextSize(TEXTSIZE);
        info.setGravity(Gravity.CENTER_HORIZONTAL);
        linlay.setGravity(Gravity.CENTER);
        linlay.addView(info);

        LinearLayout linlay2=new LinearLayout(this);
        linlay2.setOrientation(LinearLayout.HORIZONTAL);

        EditText N1=new EditText(this);
        N1.setHint("first number");
        N1.setInputType(InputType.TYPE_CLASS_NUMBER);
        N1.setGravity(Gravity.HORIZONTAL_GRAVITY_MASK);
        N1.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        N1.setTextSize(TEXTSIZE);
        linlay2.addView(N1);

        TextView signo=new TextView(this);
        signo.setText(" ? ");
        signo.setTextSize(TEXTSIZE);
        signo.setGravity(Gravity.CENTER_HORIZONTAL);
        linlay2.addView(signo);
        EditText N2=new EditText(this);



        N2.setInputType(InputType.TYPE_CLASS_NUMBER);
        N2.setGravity(Gravity.HORIZONTAL_GRAVITY_MASK);
        N2.setHint("second number");
        N2.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        N2.setTextSize(TEXTSIZE);
        linlay2.addView(N2);
        linlay2.setGravity(Gravity.CENTER_HORIZONTAL);

        TextView ig=new TextView(this);
        ig.setText(" = ");
        ig.setTextSize(TEXTSIZE);
        ig.setGravity(Gravity.CENTER_HORIZONTAL);
        linlay2.addView(ig);

        TextView result= new TextView(this);
        result.setTextSize(TEXTSIZE);
        result.setGravity(Gravity.CENTER_HORIZONTAL);


        Button botsum= new Button(this);
        botsum.setText("+");
        botsum.setLayoutParams( new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        botsum.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View view) {
                                        int nu1 =readNumber(N1);
                                        int nu2= readNumber(N2);
                                        result.setText(Integer.toString(nu1+nu2));
                                        signo.setText(" + ");
                                      }
                                  });

        Button botres= new Button(this);
        botres.setText("-");
        botres.setLayoutParams( new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        botres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int nu1 =readNumber(N1);
                int nu2= readNumber(N2);
                result.setText(Integer.toString(nu1-nu2));
                signo.setText(" - ");
            }
        });

        Button botpor= new Button(this);
        botpor.setText("x");
        botpor.setLayoutParams( new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        botpor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int nu1 =readNumber(N1);
                int nu2= readNumber(N2);
                result.setText(Integer.toString(nu1*nu2));
                signo.setText(" x ");
            }
        });

        Button botdiv= new Button(this);
        botdiv.setText("/");
        botdiv.setLayoutParams( new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        botdiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int nu1 =readNumber(N1);
                int nu2= readNumber(N2);
                if(nu2==0){
                    result.setText("incalculable");
                }else {
                    result.setText(Integer.toString(nu1 / nu2));
                }
                signo.setText(" / ");
            }
        });
        LinearLayout linlay3=new LinearLayout(this);
        linlay3.setOrientation(LinearLayout.HORIZONTAL);
        linlay3.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout linlay4=new LinearLayout(this);
        linlay4.setOrientation(LinearLayout.HORIZONTAL);
        linlay4.setGravity(Gravity.CENTER_HORIZONTAL);


        botsum.setTextSize(TEXTSIZE);
        botdiv.setTextSize(TEXTSIZE);
        botpor.setTextSize(TEXTSIZE);
        botres.setTextSize(TEXTSIZE);
        linlay2.addView(result);
        linlay.addView(linlay2);
        linlay3.addView(botsum);
        linlay3.addView(botres);
        linlay4.addView(botpor);
        linlay4.addView(botdiv);
        linlay.addView(linlay3);
        linlay.addView(linlay4);
        setContentView(linlay);

    }
}
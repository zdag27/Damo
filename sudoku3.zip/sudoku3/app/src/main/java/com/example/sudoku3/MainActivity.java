package com.example.sudoku3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    public void main(String[] args) {
        String string = "";
        try {
            InputStream inputStream = getAssets().open("sudokus.txt");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            string = new String(buffer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    SQLiteDatabase sqLiteDatabase;
    Sudoku[] listsudokus;
    String[] input = new String[40];

    private class Sudoku{
        String name;
        String[] textsudoku;
        Button bt;
        public void createButton() {
            bt = new Button(MainActivity.this);
            bt.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    Intent intent = new Intent(MainActivity.this, sudoku4.class);
                    intent.putExtra("textsudoku", textsudoku);
                    intent.putExtra("difficulty", name);
                    startActivity(intent);
                }
            });
            bt.setText(name + " mode");
            bt.setTextSize(20);
            bt.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT
            ));
        }
    }
    private void readSudokus(){
        /*
        Integer inputPos=0;
        try {
            InputStream inputStream = getAssets().open("sudoku.txt");
            BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
            String line;
            while ((line = rd.readLine()) !=null ){
                input[inputPos] = line;
                inputPos++;
            }
            rd.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        listsudokus=new Sudoku[(inputPos+1)/10];
        for (int i =0; i<listsudokus.length; i++){
            Sudoku sudoku = new Sudoku();
            listsudokus[i]=sudoku;
            int pos = 10*i;
            sudoku.name=input[pos];
            sudoku.textsudoku= new String[9];

            for (int j=0; j<9; j++){
                sudoku.textsudoku[j]=input[pos+1+j];
            }
        }

         */
        String[] listname=((MyPersistence)getApplication()).getlistname();
        listsudokus=new Sudoku[listname.length];
        for (int i =0; i<listsudokus.length; i++){
            Sudoku sudoku = new Sudoku();
            listsudokus[i]=sudoku;
            sudoku.name=listname[i];
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout linlay = new LinearLayout(this);
        linlay.setOrientation(LinearLayout.VERTICAL);
        linlay.setGravity(Gravity.CENTER);
        TextView enunciado=new TextView(this);
        enunciado.setTextSize(20);
        enunciado.setText("Lets play sudoku");
        enunciado.setTextColor(Color.BLACK);
        enunciado.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        linlay.addView(enunciado);
        readSudokus();
        for (int i =0;i< listsudokus.length;i++){
            listsudokus[i].createButton();
            linlay.addView(listsudokus[i].bt);
        }
        setContentView(linlay);

    }
    @Override
    protected  void onStart(){
        super.onStart();
        Log.i("onstart2","*****************************");
    }
    @Override
    protected  void onRestart(){
        super.onRestart();
        Log.i("onr2","*****************************");
    }
    @Override
    protected  void onResume(){
        super.onResume();
        Log.i("onre2","*****************************");
        for (int i =0;i< listsudokus.length;i++) {
            if (!((MyPersistence) getApplication()).itsaved(listsudokus[i].name)) {
                listsudokus[i].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
            } else {
                listsudokus[i].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
            }
        }
    }
    @Override
    protected  void onStop(){
        super.onStop();
        Log.i("os2","*****************************");
    }
    @Override
    protected  void onPause(){
        super.onPause();
        Log.i("onpa2","*****************************");

    }
    @Override
    protected  void onDestroy(){
        super.onDestroy();
        Log.i("onde2","*****************************");
    }
}
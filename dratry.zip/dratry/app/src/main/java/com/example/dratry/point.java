package com.example.dratry;

public class point {
    double x,y;
    public point(){
        x=y=0;
    }
    public point(double xa,double ya){
        x=xa;
        y=ya;
    }
    public static point sum(point p, point o){
        return new point(p.x+o.x,p.y+o.y);
    }
    public static point res(point p, point o){
        return new point(p.x-o.x,p.y-o.y);
    }
    public static point mul(double p, point o){
        return new point(p*o.x,p*o.y);
    }
    public static point div(point p, double o){
        return new point(p.x/o,p.y/o);
    }
    public static double abs(point p){
        return Math.sqrt(p.x*p.x+p.y*p.y);
    }
    public static double norm(point p){
        return (p.x*p.x+p.y*p.y);
    }
    public static point polar(double r, double a){
        return new point(r*Math.cos(a),r*Math.sin(a));
    }
    public static double scalarprod(point p,point o){
        return (p.x*o.x+p.y*o.y);
    }
    public static point uni(point p){
        return point.div(p,point.abs(p));
    }
    public static point ort(point p){
        return new point(-p.y,p.x);
    }
    public static point world2reference(point center,point right, point p){
        point cp=point.res(p,center);
        point cr=point.res(right,center);
        point ct=ort(cr);
        return new point(scalarprod(cp,cr)/norm(cr),scalarprod(cp,ct)/norm(ct));
    }
    public static point reference2world(point center,point right, point p){
        point cr=point.res(right,center);
        point ct=ort(cr);
        return point.sum(center,point.sum(point.mul(p.x,cr),point.mul(p.y,ct)));
    }
}

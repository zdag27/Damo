package com.example.a2actslab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class difficultymenu extends AppCompatActivity {
Context THIS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        THIS=this;
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_difficultymenu);
        LinearLayout lin;
        lin = new LinearLayout(this);
        lin.setOrientation(LinearLayout.VERTICAL);
        lin.setGravity(Gravity.CENTER);
        Button rtbt=new Button(this);
        rtbt.setText("<=");
        rtbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        rtbt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        LinearLayout lu;
        lu = new LinearLayout(this);
        lu.setOrientation(LinearLayout.HORIZONTAL);
        lu.addView(rtbt);
        lin.addView(lu);
        TextView enunciado=new TextView(this);
        enunciado.setText("Select a mode");
        enunciado.setTextSize(20);
        Button diffbt=new Button(this);
        diffbt.setText("Hard");
        diffbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(THIS,sudoku2.class);
                intent.putExtra("param1",2);
                startActivity(intent);
            }
        });
        diffbt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        Button ezbt=new Button(this);
        ezbt.setText("Easy");
        ezbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(THIS,sudoku2.class);
                intent.putExtra("param1",0);
                startActivity(intent);
            }
        });
        ezbt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        Button mebt=new Button(this);
        mebt.setText("Medium");
        mebt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(THIS,sudoku2.class);
                intent.putExtra("param1",1);
                startActivity(intent);
            }
        });
        mebt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        lin.addView(ezbt);
        lin.addView(mebt);
        lin.addView(diffbt);
        setContentView(lin);
    }
}
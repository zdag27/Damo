package com.example.dratry;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int w,h,s;
    LinearLayout linLay;
    ImageView imageView;
    Bitmap bitmap;
    Canvas canvas;
    Paint paint;
    camaramanager c;
    ArrayList<Polygonal> history;
    private point canonic2screen(point p){
        return new point(p.x*s/2+s/2,s/2-p.y*s/2);
    }
    private point screen2canonic(point p){
        return new point((p.x-s/2)/s*2,-(p.y-s/2)/s*2);
    }

    private void drawPol(Polygonal pol){
        Path path=new Path();
        point[] list= pol.list;
        point p=canonic2screen(c.world2camara(list[0]) );
        path.moveTo((int)p.x,(int)p.y);
        for (int i = 1; i < list.length ; i++) {
            p=canonic2screen(c.world2camara(list[i]));
            path.lineTo((int)(p.x),(int)(p.y));
        }
        path.close();
        paint=new Paint();
        int r,g,b;
        r=pol.re;
        b=pol.b;
        g=pol.g;
        paint.setARGB(255,r,g,b);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(path,paint);
        paint=new Paint();
        paint.setARGB(255,255-r,255-g,255-b);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((int)(pol.r*(point.abs(point.res(canonic2screen(c.world2camara(list[list.length/2])),canonic2screen(c.world2camara(list[0]))))))/5f);
        canvas.drawPath(path,paint);
    }

    public void drawAll(){
        canvas.drawColor(Color.RED);
        for (int i = 0; i < history.size(); i++) {
            drawPol(history.get(i));
        }
        drawaxes();
        imageView.invalidate();
    }
    public void drawaxes(){
        Path path=new Path();
        paint.setStrokeWidth((int)((point.abs(point.res(canonic2screen(c.world2camara(new point(0,900))),canonic2screen(c.world2camara(new point(0,-900)))))))/100000f);
        point p=canonic2screen(c.world2camara(new point(0,0)) );
        path.moveTo((int)p.x,(int)p.y);
        p=canonic2screen(c.world2camara(new point(0,900)));
        path.lineTo((int)(p.x),(int)(p.y));
        p=canonic2screen(c.world2camara(new point(0,-900)));
        path.lineTo((int)(p.x),(int)(p.y));
        path.close();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path,paint);
        imageView.invalidate();
        Path path2=new Path();
        p=canonic2screen(c.world2camara(new point(0,0)) );
        path2.moveTo((int)p.x,(int)p.y);
        p=canonic2screen(c.world2camara(new point(900,0)));
        path2.lineTo((int)(p.x),(int)(p.y));
        p=canonic2screen(c.world2camara(new point(-900,0)));
        path2.lineTo((int)(p.x),(int)(p.y));
        path2.close();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path2,paint);
        imageView.invalidate();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        history=new ArrayList<Polygonal>();
        //setContentView(R.layout.activity_main);
        linLay = new LinearLayout(this);
        linLay.setOrientation(LinearLayout.VERTICAL);
        linLay.setGravity(Gravity.CENTER);
        imageView= new ImageView(this);
        linLay.addView(imageView);
        Point p=new Point();
        getWindowManager().getDefaultDisplay().getSize(p);
        w=p.x;
        h=p.y;
        s=(int) (w*0.9);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(s,s));
        bitmap=Bitmap.createBitmap(s,s, Bitmap.Config.ARGB_8888);
        canvas= new Canvas();
        imageView.setImageBitmap(bitmap);
        canvas.setBitmap(bitmap);
        canvas.drawColor(Color.RED);
        paint=new Paint();
        c=new camaramanager();
        Button bt=new Button(this);
        bt.setText("New pol");
        bt.setTextSize(20);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Polygonal poli=new Polygonal();
                history.add(poli);
                //drawPol(poli);
                drawAll();
            }
        });
        linLay.addView(bt);
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                System.out.println("TOUCH "+motionEvent.toString());
                if((motionEvent.getPointerCount()!=1 && motionEvent.getPointerCount()!=2) || motionEvent.getAction()!=MotionEvent.ACTION_MOVE){
                    c.touch();
                }else if(motionEvent.getPointerCount()==1){
                    point finger=new point(motionEvent.getX(),motionEvent.getY());
                    c.touch(screen2canonic(finger));
                    drawAll();
                }else{
                    point finger1=new point(motionEvent.getX(0),motionEvent.getY(0));
                    point finger2=new point(motionEvent.getX(1),motionEvent.getY(1));
                    c.touch(screen2canonic(finger1),screen2canonic(finger2));
                    drawAll();
                }
                return true;
            }
        });
        setContentView(linLay);
    }
}
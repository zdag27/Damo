package com.example.sudoku3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.graphics.Point;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class sudoku4 extends AppCompatActivity {
    int width;
    SQLiteDatabase sqLiteDatabase;
    int height;
    int btsize;
    boolean won;
    Button reload;
    Cell[][] table;
    Cell[] lista;
    int fi;
    TextView enunciado;
    String[] textsudoku;
    String stringname;
    MediaPlayer player;
    private class Cell{
        int val;
        Button bt;
        boolean fixed;
        int x;
        int y;
        Cell(Context THIS,int ini,int cx,int cy){
            x=cx;
            y=cy;
            val=ini;
            bt=new Button(THIS);
            bt.setText(val==0?"":Integer.toString(val));
            bt.setLayoutParams(new LinearLayout.LayoutParams(btsize,btsize));
            bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
            bt.setTextSize(btsize/8);
            fixed=val!=0;

            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if(fixed) return;
                    if(!won){
                        val=(val+1)%10;
                        bt.setText(val==0?"":Integer.toString(val));
                        for (int q = 0; q < fi; q++) {
                            lista[q].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
                        }
                        if(val!=0){
                            if(Revision(x,y)){
                                bt.setTextColor(Color.RED);
                            }else{
                                bt.setTextColor(Color.BLUE);
                                won=gano();
                                if(won){
                                    enunciado.setText("Well done!");
                                    player=MediaPlayer.create(THIS,R.raw.winsong);
                                    player.start();
                                }
                            }
                        }
                    }
                }
            });
        }
    }
void reload(Cell act,int newval){
    if(act.fixed) return;
    if(!won){
        act.val=newval;
        act.bt.setText(act.val==0?"":Integer.toString(act.val));
        if(act.val!=0){
            if(Revision(act.x,act.y)){
                act.bt.setTextColor(Color.RED);
            }else{
                act.bt.setTextColor(Color.BLUE);
                won=gano();
                if(won){
                    enunciado.setText("Well done!");
                    player=MediaPlayer.create(getApplicationContext(),R.raw.winsong);
                    player.start();
                }
            }
        }
    }
}
private String table2string(){
        String text="";
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            text+=Integer.toString(table[i][j].val);
        }
        text+="\n";
    }
    return text;
}

private void table2string(String text){
        String[] lines=text.split("\n");
    for (int i = 0; i < 9; i++) {
        for (int j = 0; j < 9; j++) {
            table[i][j].val=lines[i].charAt(j)-'0';
            table[i][j].bt.setText(table[i][j].val==0?"":Integer.toString(table[i][j].val));
            if(table[i][j].fixed) continue;
            if(table[i][j].val!=0){
                if(Revision(table[i][j].x,table[i][j].y)){
                    table[i][j].bt.setTextColor(Color.RED);
                }else{
                    table[i][j].bt.setTextColor(Color.BLUE);
                    won=gano();
                    if(won){
                        enunciado.setText("Well done!");
                        player=MediaPlayer.create(getApplicationContext(),R.raw.winsong);
                        player.start();
                    }
                }
            }

        }
    }
}
    boolean gano(){
        boolean vinccera=true;
        int col=0;
        int row;
        while(vinccera && col<9){
            row=0;
            while(vinccera && row<9){
                if(!table[col][row].fixed){
                    if(table[col][row].bt.getCurrentTextColor()==Color.RED || table[col][row].val==0){
                        vinccera=false;
                    }
                }
                row+=1;
            }
            col+=1;
        }
        return vinccera;
    }

    boolean Revision(int i,int j){
        Boolean res=false;
        Cell origen=table[i][j];
        int n=0;
        fi=0;
        while(n<9){
            if(n!=j){
                if(table[i][n].val== origen.val){
                    lista[fi]=table[i][n];
                    res=true;
                    table[i][n].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    fi+=1;
                }
            }
            if(n!=i){
                if(table[n][j].val== origen.val){
                    lista[fi]=table[n][j];
                    res=true;
                    table[n][j].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    System.out.println();
                    fi+=1;
                }
            }
            n+=1;
        }
        for (int t = i/3*3; t < i/3*3+3; t++) {
            for (int m = j/3*3; m < j/3*3+3; m++) {
                if((t!=i||j!=m) && table[i][j].val==table[t][m].val){
                    table[t][m].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    lista[fi]=table[t][m];
                    fi+=1;
                    res=true;
                }
            }
        }
        return res;
    }


    private void readSudokus(){
        Integer inputPos=0;
        try {
            InputStream inputStream = getAssets().open("sudoku.txt");
            BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
            String line;
            String[] input = new String[40];
            while ((line = rd.readLine()) !=null ){
                input[inputPos] = line;
                inputPos++;
            }
            rd.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        for(int i=0;i<9;++i){
            for(int j=0;j<9;++j){
                table[i][j]=new Cell(this,textsudoku[i].charAt(j)-'0',i,j);
            }
        }
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Intent intent = getIntent();
        stringname=intent.getStringExtra("difficulty");
        textsudoku=((MyPersistence)getApplication()).getListsudokus(stringname);
        won=false;
        enunciado=new TextView(this);
        enunciado.setText("Have fun!");
        enunciado.setTextSize(20);
        enunciado.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        Button rtbt=new Button(this);
        rtbt.setText("<=");
        rtbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        rtbt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        rtbt.setGravity(Gravity.TOP);
        rtbt.setGravity(Gravity.LEFT);

        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        won=false;
        fi=0;
        Point point=new Point();
        getWindowManager().getDefaultDisplay().getSize(point);
        width=point.x;height=point.y;btsize=width/10;
        LinearLayout lin= new LinearLayout(this);
        lin.setOrientation(LinearLayout.VERTICAL);
        lin.setGravity(Gravity.CENTER);
        LinearLayout lu= new LinearLayout(this);
        lu.setOrientation(LinearLayout.HORIZONTAL);
        lu.addView(rtbt);
        lin.addView(lu);
        lin.addView(enunciado);
        table=new Cell[9][9];
        lista=new Cell[9*3];
        for(int i=0;i<9;++i){
            LinearLayout lin2= new LinearLayout(this);
            lin2.setOrientation(LinearLayout.HORIZONTAL);
            lin2.setGravity(Gravity.CENTER_HORIZONTAL);
            for(int j=0;j<9;++j){
                table[i][j]=new Cell(this,textsudoku[i].charAt(j)-'0',i,j);
                lin2.addView(table[i][j].bt);
            }
            lin.addView(lin2);
        }
        Button reset=new Button(this);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                for (int i = 0; i < 9; i++) {
                    for (int j = 0; j < 9; j++) {
                        if(!table[i][j].fixed){
                            table[i][j].bt.setText(0==0?"":Integer.toString(0));
                            table[i][j].bt.setTextColor(Color.BLACK);
                            table[i][j].val=0;
                        }
                        table[i][j].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
                    }
                }
                won=false;
                enunciado.setText("Have fun!");

            }
        });
        reset.setText("Reset");
        reset.setLayoutParams(new LinearLayout.LayoutParams(btsize*2,btsize));
        reset.setTextSize(btsize/6);
        Button save=new Button(this);
        save.setLayoutParams(new LinearLayout.LayoutParams(btsize*2,btsize));
        save.setTextSize(btsize/6);
        save.setText("SAVE");
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                /*
                try {
                    FileOutputStream ou=openFileOutput(stringname,MODE_PRIVATE);
                    ou.write(table2string().getBytes());
                }catch(Exception e){
                    finish();
                }
                 */
                ((MyPersistence)getApplication()).saveSudoku(stringname,table2string());
                reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));

            }
        });
        reload=new Button(this);
        reload.setLayoutParams(new LinearLayout.LayoutParams(btsize*2,btsize));
        reload.setTextSize(btsize/6);
        reload.setText("RLD");
        reload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {/*
                    try {
                        InputStream inputStream = openFileInput(stringname);
                        BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
                        String line;
                        String content="";
                        while ((line = rd.readLine()) !=null )
                            content += line+"\n";
                        table2string(content);
                        System.out.println(content);
                        rd.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    */
                    table2string(((MyPersistence)getApplication()).restore(stringname));
                }catch(Exception e){
                    finish();
                }

            }
        });
        LinearLayout lin2= new LinearLayout(this);
        lin2.setOrientation(LinearLayout.HORIZONTAL);
        lin2.setGravity(Gravity.CENTER_HORIZONTAL);
        lin2.addView(save);
        lin2.addView(reset);
        lin2.addView(reload);
        lin.addView(lin2);
        Button erase=new Button(this);
        erase.setLayoutParams(new LinearLayout.LayoutParams(btsize*2,btsize));
        erase.setTextSize(btsize/6);
        erase.setText("Erase");
        erase.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                ((MyPersistence)getApplication()).eraseme(stringname);
                reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
            }
        });
        lin.addView(erase);
        setContentView(lin);

    }

    @Override
    protected  void onStart() {
        super.onStart();
        Log.i("onstart2", "*****************************");
        if (!((MyPersistence) getApplication()).itsaved(stringname)) {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
        } else {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
        }
    }
    @Override
    protected  void onRestart(){
        super.onRestart();
        Log.i("onr2","*****************************");
        if (!((MyPersistence) getApplication()).itsaved(stringname)) {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
        } else {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
        }
    }
    @Override
    protected  void onResume(){
        super.onResume();
        if (!((MyPersistence) getApplication()).itsaved(stringname)) {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#c2c2c2")));
        } else {
            reload.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
        }
    }
}


    //----------------------------------------------------------------------------------------

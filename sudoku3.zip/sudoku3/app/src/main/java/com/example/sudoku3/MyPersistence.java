package com.example.sudoku3;

import android.annotation.SuppressLint;
import android.app.Application;
import android.content.Context;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MyPersistence extends Application {
    String[] input;
    String[][] listsudokus;
    String [] listname;
    SQLiteDatabase sqLiteDatabase;
     @Override
    public void onCreate(){
         super.onCreate();
         input=new String [40];
         Integer inputPos=0;
         try {
             InputStream inputStream = getAssets().open("sudoku.txt");
             BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
             String line;
             while ((line = rd.readLine()) !=null ){
                 input[inputPos] = line;
                 inputPos++;
             }
             rd.close();
         } catch (IOException e) {
             e.printStackTrace();
         }
         /*
         listsudokus=new Sudoku[(inputPos+1)/10];
         for (int i =0; i<listsudokus.length; i++){
             Sudoku sudoku = new Sudoku();
             listsudokus[i]=sudoku;
             int pos = 10*i;
             sudoku.name=input[pos];
             sudoku.textsudoku= new String[9];

             for (int j=0; j<9; j++){
                 sudoku.textsudoku[j]=input[pos+1+j];
             }
         }*/
         listname=new String[(inputPos+1)/10];
         listsudokus=new String[(inputPos+1)/10][];
         for (int i =0; i<listsudokus.length; i++){
             int pos = 10*i;
             listname[i]=input[pos];
             listsudokus[i]= new String[9];
             for (int j=0; j<9; j++){
                 listsudokus[i][j]=input[pos+1+j];
             }
         }
         sqLiteDatabase= SQLiteDatabase.openOrCreateDatabase(getFilesDir().getPath() + "sudokustatesdatebase.sql", null);
         sqLiteDatabase.execSQL("Create table if not exists sudokustates (name VARCHAR(100) Primary key,description TEXT)");
     }
    public String[] getlistname(){
         return listname;
    }
    public String[] getListsudokus(String name){
         String [] aux=new String[0];
        for (int i =0; i<listsudokus.length; i++){
            int pos = 10*i;
            if (listname[i].equals(name)){
                return listsudokus[i];
            }
        }
        return aux;
    }
    public void saveSudoku(String name, String descr){
         name= DatabaseUtils.sqlEscapeString(name);
         descr=DatabaseUtils.sqlEscapeString(descr).replace("\n",",");
         try{
            sqLiteDatabase.execSQL("insert into sudokustates values("+name+","+descr+")");
         }catch (Exception e){
             sqLiteDatabase.execSQL("update sudokustates set description="+descr+" where name="+name);
        }
         /*
        try {
            FileOutputStream ou=openFileOutput(name,MODE_PRIVATE);
            ou.write(descr.getBytes());
            ou.close();
        }catch(Exception e){
            System.exit(1);
        }

          */
    }
    @SuppressLint("Range")
    public String restore(String name){
        name= DatabaseUtils.sqlEscapeString(name);
        Cursor cursor=sqLiteDatabase.rawQuery("Select description from sudokustates where name="+name,null);
        if(cursor.getCount()==0){return "";}
        cursor.moveToFirst();
        return cursor.getString(cursor.getColumnIndex("description")).replace(",","\n");
    }

    public boolean itsaved(String stringname){
         Boolean colorear=false;
        try {
            Cursor cursor = sqLiteDatabase.rawQuery("Select description from sudokustates where name='" + stringname+"'", null);
            if (cursor.getCount() != 0) {
                colorear=true;
            }
        }catch (Exception e){}
        return colorear;
    }
    public void eraseme(String s){
        try {
            sqLiteDatabase.execSQL("Delete from sudokustates where name='" + s+"'");
            System.out.println("eliminado");
        }catch(Exception r) {
            System.out.println(r);
            System.out.println("no hice nada");
        }
    }
    /*
        String content="";
        try {
            InputStream inputStream = openFileInput(name);
            BufferedReader rd = new BufferedReader(new InputStreamReader(inputStream,"UTF-8"));
            String line;

            while ((line = rd.readLine()) !=null )
                content += line+"\n";
            System.out.println(content);
            rd.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
        return (content);
    }

          */
}

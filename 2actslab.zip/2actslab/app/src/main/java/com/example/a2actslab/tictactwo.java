package com.example.a2actslab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Point;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class tictactwo extends AppCompatActivity {
    int width,height,btsize;
    Cell[][] table;
    String Turn;
    TextView enunciado;
    LinearLayout lin;
    boolean won;
    int over;
    Cell retry;
    private class Cell{
        String V;
        Button bt;
        int x;
        int y;
        Cell(Context este, int i, int j){
            bt=new Button(este);
            V="?";
            bt.setText(V);
            x=i;
            y=j;
            bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#00FF00")));
            bt.setLayoutParams(new LinearLayout.LayoutParams(btsize,btsize));
            bt.setTextSize(btsize/5);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if (x < 0) {
                        won=false;
                        over=0;
                        enunciado.setText("lets get started player X starts");
                        for (int i = 0; i < 3; ++i) {
                            for(int j=0; j<3;++j){
                                table[i][j].V="?";
                                table[i][j].bt.setText("?");
                                table[i][j].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#00FF00")));

                            }
                        }
                        lin.removeView(retry.bt);
                    } else {
                        checkclick(x, y);

                    }
                }
            });
        }
    }

    Boolean inside(int i){
        return 0<=i && i<3;
    }
    Boolean inside(int i,int j){
        return inside(i) && inside(j);
    }

    Boolean checkDirection( int i, int j, int di, int dj){
        for(;inside(i,j);i+=di,j+=dj ){
            if(!table[i][j].V.equals(Turn)) return false;
        }
        return true;
    }


    void checkclick(int x, int y){
        if(!won && table[x][y].V.equals("?")) {
            over=++over;
            table[x][y].V = Turn;
            table[x][y].bt.setText(Turn);
            table[x][y].bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor(Turn.equals("X") ? "#FF0000" : "#0000FF")));
            for (int i = 0; i < 3; ++i) {
                if (checkDirection(i, 0, 0, 1)) {
                    enunciado.setText("Player " + Turn + " has won");
                    lin.addView(retry.bt);
                    won = true;
                    return;
                }
            }
            for (int j = 0; j < 3; ++j) {
                if (checkDirection(0, j, 1, 0)) {
                    enunciado.setText("Player " + Turn + " has won");
                    lin.addView(retry.bt);
                    won = true;
                    return;
                }
            }
            if (checkDirection(0, 0, 1, 1) || checkDirection(0, 2, 1, -1)) {
                enunciado.setText("Player " + Turn + " has won");
                lin.addView(retry.bt);
                won = true;
                return;
            }
            Turn = Turn.equals("X") ? "O" : "X";
            enunciado.setText("its player " + Turn + " turn");

            if (over==8 && !won){
                won=true;
                lin.addView(retry.bt);
                enunciado.setText("its a tie");
                return;
            }
        }


    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);
        lin = new LinearLayout(this);
        won=false;
        over = 0;
        lin.setOrientation(LinearLayout.VERTICAL);
        Button rtbt=new Button(this);
        rtbt.setText("<=");
        rtbt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
        rtbt.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        LinearLayout lu;
        lu = new LinearLayout(this);
        lu.setOrientation(LinearLayout.HORIZONTAL);
        lu.addView(rtbt);
        lin.addView(lu);
        Point point=new Point();
        getWindowManager().getDefaultDisplay().getSize(point);
        width=point.x;
        height=point.y;
        btsize=width/4;
        Turn="X";
        table=new Cell[3][3];
        enunciado=new TextView(this);
        enunciado.setText("lets get started player X starts");
        enunciado.setTextSize(btsize/7);
        enunciado.setGravity(Gravity.CENTER);
        lin.addView(enunciado);
        for (int i = 0; i < 3; ++i) {
            LinearLayout linaux= new LinearLayout(this);
            linaux.setOrientation(LinearLayout.HORIZONTAL);
            linaux.setGravity(Gravity.CENTER);
            for(int j=0; j<3;++j){
                table[i][j]=new Cell(this,i,j);
                linaux.addView(table[i][j].bt);
            }
            lin.addView(linaux);
        }

        retry=new Cell(this,-1,-1);
        retry.V="Play again";
        retry.bt.setText(retry.V);
        retry.bt.setLayoutParams(new LinearLayout.LayoutParams(btsize*3,btsize));
        retry.bt.setTextSize(btsize/10);
        retry.bt.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#808080")));
        lin.setGravity(Gravity.CENTER);
        setContentView(lin);
    }
}
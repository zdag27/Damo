package com.example.a2actslab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
Context THIS;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        THIS=this;
        //setContentView(R.layout.activity_main);
        LinearLayout lin = new LinearLayout(this);
        lin.setOrientation(LinearLayout.VERTICAL);
        lin.setGravity(Gravity.CENTER);
        LinearLayout lin2 = new LinearLayout(this);
        lin2.setOrientation(LinearLayout.HORIZONTAL);
        lin2.setGravity(Gravity.CENTER);
        TextView text=new TextView(this);
        text.setText("which one do you want to play?");
        text.setTextSize(26);
        Button btsudok= new Button(this);
        btsudok.setText("TikTakToe");
        String [] starr={"a","b","c"};
        btsudok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(THIS,tictactwo.class);
                intent.putExtra("param1",starr);
                startActivity(intent);
            }
        });

        Button bttikitaki= new Button(this);
        bttikitaki.setText("Sudoku");
        bttikitaki.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(THIS,difficultymenu.class);
                startActivity(intent);
            }
        });
        btsudok.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        bttikitaki.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        text.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
        ));
        lin.addView(text);
        lin2.addView(btsudok);
        lin2.addView(bttikitaki);
        lin.addView(lin2);
        setContentView(lin);

    }
    @Override
    protected  void onStart(){
        super.onStart();
        Log.i("onstart","*****************************");
    }
    @Override
    protected  void onRestart(){
        super.onRestart();
        Log.i("onr","*****************************");
    }
    @Override
    protected  void onResume(){
        super.onResume();
        Log.i("onre","*****************************");
    }
    @Override
    protected  void onStop(){
        super.onStop();
        Log.i("os","*****************************");
    }
    @Override
    protected  void onPause(){
        super.onPause();
        Log.i("onpa","*****************************");

    }
    @Override
    protected  void onDestroy(){
        super.onDestroy();
        Log.i("onde","*****************************");
    }

}
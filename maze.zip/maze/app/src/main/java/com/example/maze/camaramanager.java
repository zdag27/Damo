package com.example.maze;

import android.hardware.camera2.CameraManager;

public class camaramanager {
    point center,right,worldfinger1, worldfinger2;
    int numfinger;
    camaramanager(){
        center=new point(0,0);
        right=new point (1,0);
        numfinger=0;
    }
    public point camara2world(point p){
        return point.reference2world(center,right,p);
    }
    public point world2camara(point p){
        return point.world2reference(center,right,p);
    }
    public void touch(){
        numfinger=0;
    }
    public void touch(point camerafinger){
        if(numfinger!=1){
            numfinger=1;
            worldfinger1=camara2world(camerafinger);
            return;
        }
        point worldfingerbis=camara2world(camerafinger);
        point move =point.res(worldfinger1,worldfingerbis);
        center=point.sum(center,move);
        right=point.sum(right,move);
    }
    public void touch(point camerafinger1,point camerafinger2){
        if(numfinger!=2){
            numfinger=2;
            worldfinger1=camara2world(camerafinger1);
            worldfinger2=camara2world(camerafinger2);
            return;
        }
        point centerbis=point.world2reference(camerafinger1,camerafinger2,new point(0,0));
        point rightbis=point.world2reference(camerafinger1,camerafinger2,new point(1,0));
        center=point.reference2world(worldfinger1,worldfinger2,centerbis);
        right=point.reference2world(worldfinger1,worldfinger2,rightbis);

    }
}

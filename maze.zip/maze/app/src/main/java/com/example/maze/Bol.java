package com.example.maze;

import java.util.ArrayList;

public class Bol {
    point c,destination;
    double r,speedfactor;
    boolean thereisdestination;
    public Bol(point inc,double inr){
        c=inc;
        r=inr;
        thereisdestination=false;
        destination=new point(1,0);
        speedfactor=4;
    }


    public void move(double delta){
        if(!thereisdestination){
            return;
        }
        double d=point.distance(c,destination);
        double traversal=r*speedfactor*delta;
        if(d<traversal){
            c=destination;
            return;
        }
        point direction=point.uni(point.res(destination,c));
        c=point.sum(c,point.mul(traversal,direction));
    }

    public void movedir(double delta, point newdestination){
        if (!thereisdestination) return;
        double d =point.distance(c, newdestination);
        double tranversed = r*speedfactor*delta;
        if(d<tranversed){
            c=newdestination;
            return;
        }
        point direction = point.uni(point.res(newdestination,c));
        c = point.sum(c,point.mul(tranversed,direction));
    }
    public void pushAside(point p){
        point p2c = point.res(c,p);
        double distance = point.abs(p2c);
        if(distance>= r) return;
        if (distance<0.000001) return;
        c=point.sum(p, point.mul(r, point.uni(p2c)) );

    }

    public void pushAside(Segment segment){
        point p1 = segment.p1;
        point p2 = segment.p2;
        pushAside(segment.p1);
        pushAside(segment.p2);
        point p1p2=point.res(p2,p1);
        point p1c =point.res(c,p1);
        double scalarprod=point.scalarprod(p1p2, p1c);
        if (scalarprod<=0) return;
        if(scalarprod >= point.norm(p1p2)) return;
        point projection=point.sum(p1, point.mul(scalarprod/point.norm(p1p2), p1p2));
        pushAside(projection);

    }

    public void pushAside(SegmentsManeger segmentsManeger){
        ArrayList<Segment> list = segmentsManeger.list;
        for (int i = 0; i < list.size(); i++) {
                Segment s=list.get(i);
                if(s.p1.x>c.x-2 && s.p1.x<c.x+2 && s.p2.x>c.x-2 && s.p2.x<c.x+2 && s.p1.y>c.y-2 && s.p1.y<c.y+2 && s.p2.y>c.y-2 && s.p2.y<c.y+2){
                    pushAside(list.get(i));
                }
        }
    }

    public void move(double delta, SegmentsManeger segmentsManeger){
        double transverse = r*speedfactor*delta;
        int steps= (int) (transverse/(r/2.0)+1);
        for (int i = 0; i < steps; i++) {
            move(delta);
            pushAside(segmentsManeger);
        }
    }
}

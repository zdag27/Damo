package com.example.maze;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Point;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    int w,h,s;
    LinearLayout linLay;
    ImageView imageView;
    Bitmap bitmap;
    Canvas canvas;
    Paint paint;
    camaramanager c;
    com.example.maze.Bol Bol;
    Handler handler;
    long time;
    final int n=14;
    SegmentsManeger segmentsManeger;
    // ArrayList<Polygonal> history;
    private point canonic2screen(point p){
        return new point(p.x*s/2+s/2,s/2-p.y*s/2);
    }
    private point screen2canonic(point p){
        return new point((p.x-s/2)/s*2,-(p.y-s/2)/s*2);
    }
    private point screen2world(point p){
        return c.camara2world(screen2canonic(p));
    }
    private point world2screen(point p){
        return canonic2screen(c.world2camara(p));
    }
    private double world2screenfactor(){
        return point.distance(world2screen(new point(0,0)),world2screen(new point (1,0)));
    }

    /*
    private void drawPol(Polygonal pol){
        Path path=new Path();
        point[] list= pol.list;
        point p=canonic2screen(c.world2camara(list[0]) );
        path.moveTo((int)p.x,(int)p.y);
        for (int i = 1; i < list.length ; i++) {
            p=canonic2screen(c.world2camara(list[i]));
            path.lineTo((int)(p.x),(int)(p.y));
        }
        path.close();
        paint=new Paint();
        int r,g,b;
        r=pol.re;
        b=pol.b;
        g=pol.g;
        paint.setARGB(255,r,g,b);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawPath(path,paint);
        paint=new Paint();
        paint.setARGB(255,255-r,255-g,255-b);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth((int)(pol.r*(point.abs(point.res(canonic2screen(c.world2camara(list[list.length/2])),canonic2screen(c.world2camara(list[0]))))))/5f);
        canvas.drawPath(path,paint);
    }
*/

    private void drawSegment(Segment segment){
        point p1=world2screen(segment.p1);
        point p2=world2screen(segment.p2);
        Path path=new Path();
        path.moveTo((float) p1.x, (float) p1.y);
        path.lineTo((float) p2.x, (float) p2.y);
        paint.setColor(Color.YELLOW);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);
        canvas.drawPath(path, paint);
    }

    public void drawdir(){
        point cor=world2screen(Bol.c);
        Path path=new Path();
        paint.setStrokeWidth((float)Bol.r*50);
        path.moveTo((int)cor.x,(int)cor.y);
        point des=world2screen(point.sum(Bol.c,point.res(Bol.destination,Bol.c)));
        path.lineTo((int)des.x,(int)des.y);
        path.close();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path,paint);
    }
    public void drawAll(){
        canvas.drawColor(Color.RED);
        point cor=world2screen(Bol.c);
        double r=Bol.r*world2screenfactor();
        paint.setColor(Color.BLACK);
        canvas.drawCircle((int)cor.x,(int)cor.y,(int)r*3,paint);
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.FILL);
        //-----------NEW
        /*
        Path path = new Path();
        path.moveTo((float) c.x, (float) c.y);
        point desti = world2screen(ball.destination);
        path.lineTo((float) desti.x, (float) desti.y);

        paint.setColor(Color.RED);
        paint.setStrokeWidth(5);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path, paint);
        */
        //----------
        cor.log();
        canvas.drawCircle((int)cor.x,(int)cor.y,(int)r,paint);

        if(Bol.c!=Bol.destination){
            drawdir();
        }else{
            paint.setColor(Color.BLACK);
            paint.setStyle(Paint.Style.FILL);
            cor.log();
            canvas.drawCircle((int)cor.x,(int)cor.y,(int)r/10,paint);
        }
        //paint.setColor(Color.BLUE);
        //paint.setStyle(Paint.Style.FILL);
        //canvas.drawCircle((int)0,(int)0,(int)100,paint);
        /*
        for (int i = 0; i < history.size(); i++) {
            drawPol(history.get(i));
        }
        */
        //drawaxes();
        ArrayList<Segment> list = segmentsManeger.list;
        for (int i = 0; i < list.size(); i++) {
            drawSegment(list.get(i));
        }
        imageView.invalidate();
    }
    public void drawaxes(){
        Path path=new Path();
        paint.setStrokeWidth((int)((point.abs(point.res(canonic2screen(c.world2camara(new point(0,900))),canonic2screen(c.world2camara(new point(0,-900)))))))/100000f);
        point p=canonic2screen(c.world2camara(new point(0,0)) );
        path.moveTo((int)p.x,(int)p.y);
        p=canonic2screen(c.world2camara(new point(0,900)));
        path.lineTo((int)(p.x),(int)(p.y));
        p=canonic2screen(c.world2camara(new point(0,-900)));
        path.lineTo((int)(p.x),(int)(p.y));
        path.close();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path,paint);
        imageView.invalidate();
        Path path2=new Path();
        p=canonic2screen(c.world2camara(new point(0,0)) );
        path2.moveTo((int)p.x,(int)p.y);
        p=canonic2screen(c.world2camara(new point(900,0)));
        path2.lineTo((int)(p.x),(int)(p.y));
        p=canonic2screen(c.world2camara(new point(-900,0)));
        path2.lineTo((int)(p.x),(int)(p.y));
        path2.close();
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawPath(path2,paint);
        imageView.invalidate();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //history=new ArrayList<Polygonal>();
        //setContentView(R.layout.activity_main);
        linLay = new LinearLayout(this);
        linLay.setOrientation(LinearLayout.VERTICAL);
        linLay.setGravity(Gravity.CENTER);
        imageView= new ImageView(this);
        linLay.addView(imageView);
        Point p=new Point();
        getWindowManager().getDefaultDisplay().getSize(p);
        w=p.x;
        h=p.y;
        s=(int) (w*0.9);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(s,s));
        bitmap=Bitmap.createBitmap(s,s, Bitmap.Config.ARGB_8888);
        canvas= new Canvas();
        imageView.setImageBitmap(bitmap);
        canvas.setBitmap(bitmap);
        segmentsManeger=new SegmentsManeger();
        //canvas.drawColor(Color.RED);
        paint=new Paint();
        c=new camaramanager();
        c.center=new point(n/2.0,n/2.0);
        c.right=new point(n,n/2.0);
        Bol=new Bol(new point(0.5,0.5),0.35);
        segmentsManeger=new SegmentsManeger(n);
        Button bt=new Button(this);
        bt.setText("New pol");
        bt.setTextSize(20);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Polygonal poli=new Polygonal();
                //history.add(poli);
                //drawPol(poli);
                drawAll();
            }
        });
        linLay.addView(bt);
        /*
                if(motionEvent.getPointerCount()!=1 &&  motionEvent.getAction()!=MotionEvent.ACTION_POINTER_UP){
                    Bol.thereisdestination=true;
                    Bol.destination=screen2canonic(new point(motionEvent.getX(),motionEvent.getY()));
                    return true;
                }
                if((motionEvent.getPointerCount()!=1 && motionEvent.getPointerCount()!=2) || motionEvent.getAction()!=MotionEvent.ACTION_MOVE){
                    c.touch();
                }else if(motionEvent.getPointerCount()==1){
                    point finger=new point(motionEvent.getX(),motionEvent.getY());
                    c.touch(screen2canonic(finger));
                    //drawAll();
                }else{
                    point finger1=new point(motionEvent.getX(0),motionEvent.getY(0));
                    point finger2=new point(motionEvent.getX(1),motionEvent.getY(1));
                    c.touch(screen2canonic(finger1),screen2canonic(finger2));
                    //drawAll();
                }
                return true;
            }
        });


         */
        imageView.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                System.out.println("TOUCH"+motionEvent.toString());
                if(motionEvent.getPointerCount()==1 &&
                        ( motionEvent.getAction()==MotionEvent.ACTION_MOVE
                                || motionEvent.getAction()==MotionEvent.ACTION_DOWN))
                {
                    point finger= new point(motionEvent.getX(), motionEvent.getY());
                    point worldfinger=screen2world(finger);
                    if( motionEvent.getAction()== MotionEvent.ACTION_DOWN) {
                        if (point.distance(worldfinger, Bol.c) < 3 * Bol.r) {
                            Bol.thereisdestination = true;
                            Bol.destination = worldfinger;
                        } else {
                            Bol.thereisdestination = false;
                            c.touch(screen2canonic(finger));
                        }
                        return true;
                    }
                    if(Bol.thereisdestination){
                        Bol.thereisdestination = true;
                        Bol.destination = worldfinger;
                    }else{
                        c.touch(screen2canonic(finger));
                    }
                    return true;
                }
                Bol.thereisdestination=false;

                if( ((motionEvent.getPointerCount()!=1) && (motionEvent.getPointerCount()!=2)) || motionEvent.getAction()!= MotionEvent.ACTION_MOVE){
                    c.touch();
                }else if(motionEvent.getPointerCount()==1){
                    point finger =new point(motionEvent.getX(), motionEvent.getY());
                    finger=screen2canonic(finger);
                    c.touch(finger);
                    //cameramaneger.touch(finger, new point(0,0));
                    //drawAll();

                }else{
                    point finger1 =new point(motionEvent.getX(0), motionEvent.getY(0));
                    point finger2 =new point(motionEvent.getX(1), motionEvent.getY(1));
                    //Log.i("finger","("+finger.x+","+finger.y+")");
                    finger1=screen2canonic(finger1);
                    finger2=screen2canonic(finger2);
                    //Log.i("finger Touch","("+finger.x+","+finger.y+")");
                    c.touch(finger1, finger2);

                }

                return true;
            }
        });

        drawAll();

        handler=new Handler();
        time=System.currentTimeMillis();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                long nexttime=System.currentTimeMillis();
                double delta=(nexttime-time)/1000.0;
                time=nexttime;
                Bol.move(delta,segmentsManeger);
                drawAll();
                handler.postDelayed(this,50);
            }
        },50);


        setContentView(linLay);
    }
}
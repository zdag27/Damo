package com.example.dratry;

import android.graphics.Point;

public class Polygonal {
    point[] list;
    double r;
    int re,g,b;
    Polygonal(){
        int n=3+(int)Math.floor(Math.random()*8);
        list=new point[n];
        point center= new point(Math.random()*2-1,Math.random()*2-1);
        r=0.1+Math.random()*0.2;
        re=(int)Math.floor(Math.random()*255);
        b=(int)Math.floor(Math.random()*255);
        g=(int)Math.floor(Math.random()*255);
        for (int i = 0; i < n; i++) {
            list[i]=point.sum(center,point.polar(r,2*Math.PI*i/n));
        }
    }
}
